# CucumberJavaTests
HotelManagementBooking
Run following maven command to execute all the tests

mvn clean install -Dtest=AllTestsRunner test
